/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { motion, useScroll, useTransform, AnimatePresence } from "motion/react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { 
  Plus, 
  Check, 
  MessageCircle, 
  Github, 
  ExternalLink,
  Code2,
  Cpu,
  Layers,
  Rocket,
  Globe
} from "lucide-react";
import { cn } from "@/src/lib/utils";

gsap.registerPlugin(ScrollTrigger);

// --- Helpers ---

const getGreeting = () => {
  const hour = new Date().getHours();
  if (hour < 12) return "Bom dia";
  if (hour < 18) return "Boa tarde";
  return "Boa noite";
};

const getWhatsAppLink = (planName: string) => {
  const greeting = getGreeting();
  const message = `Olá, Jonas! ${greeting}, me interessei pelo plano ${planName}, podemos conversar sobre isso?`;
  return `https://wa.me/5500000000000?text=${encodeURIComponent(message)}`;
};

// --- Components ---

const LogoMarquee = ({ items, speed = 30, direction = "left" }: { items: string[], speed?: number, direction?: "left" | "right" }) => {
  return (
    <div className="relative flex overflow-hidden py-12 select-none group">
      <div 
        className={cn(
          "flex min-w-full shrink-0 items-center justify-around gap-12",
          direction === "left" ? "animate-marquee" : "animate-marquee-reverse"
        )}
        style={{ "--duration": `${speed}s` } as React.CSSProperties}
      >
        {items.concat(items).map((item, i) => (
          <span 
            key={i} 
            className="text-2xl md:text-4xl font-bold text-zinc-700 hover:text-purple-500 transition-colors duration-300"
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  );
};

const RevealText = ({ children, delay = 0, className = "" }: { children: React.ReactNode, delay?: number, className?: string }) => (
  <motion.div
    initial={{ opacity: 0, y: 50, rotateX: -20, filter: "blur(10px)" }}
    whileInView={{ opacity: 1, y: 0, rotateX: 0, filter: "blur(0px)" }}
    viewport={{ once: true, margin: "-10%" }}
    transition={{ duration: 0.8, delay, ease: [0.25, 0.46, 0.45, 0.94] }}
    style={{ transformPerspective: 1000 }}
    className={className}
  >
    {children}
  </motion.div>
);

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // GSAP Smooth Reveal for sections
    const sections = gsap.utils.toArray<HTMLElement>(".reveal");
    sections.forEach((section) => {
      gsap.fromTo(section, 
        { y: 50, opacity: 0 },
        { 
          y: 0, 
          opacity: 1, 
          duration: 1, 
          ease: "power3.out",
          scrollTrigger: {
            trigger: section,
            start: "top 80%",
          }
        }
      );
    });
  }, []);

  return (
    <main ref={containerRef} className="min-h-screen bg-zinc-950 overflow-x-hidden">
      
      {/* 1. HERO SECTION */}
      <section 
        ref={heroRef}
        className="relative h-screen min-h-[600px] w-full flex flex-col items-center justify-center bg-white overflow-hidden"
      >
        {/* Split Background (High Contrast B&W) */}
        <div className="absolute inset-0 flex">
          <div className="w-1/2 h-full bg-zinc-950" />
          <div className="w-1/2 h-full bg-white relative">
             <div className="absolute inset-0 bg-white" />
          </div>
        </div>

        {/* Background Text Layer (Helvetica Now) */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden mix-blend-difference z-0">
          <motion.h1 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="text-[18vw] font-black leading-none text-white tracking-tighter whitespace-nowrap text-center flex items-center justify-center h-full"
            style={{ fontFamily: '"Helvetica Now", "Helvetica Neue", Helvetica, sans-serif' }}
          >
            JONAS AGRA
          </motion.h1>
        </div>

        {/* Title Overlay (positioned tight below JONAS AGRA) */}
        <div className="absolute inset-x-0 top-1/2 left-0 w-full flex justify-center pointer-events-none z-50 translate-y-[6vw] md:translate-y-[7vw]">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-center"
          >
            <h2 className="text-3xl md:text-5xl lg:text-7xl font-black tracking-tighter uppercase italic">
              <span className="text-white drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">SOFTWARE</span> <span className="text-black drop-shadow-[0_2px_4px_rgba(255,255,255,0.8)]">ENGINEER</span>
            </h2>
          </motion.div>
        </div>

        {/* Foreground Content */}
        <div className="relative z-10 flex flex-col items-center justify-center w-full max-w-7xl px-4 h-full pointer-events-none">
          
          <div className="relative w-full flex flex-col items-center mt-12 md:mt-0 pointer-events-auto">
            
            {/* The Photo Container */}
            <motion.div 
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 1, delay: 0.3 }}
              className="relative w-72 h-72 md:w-[500px] md:h-[500px] z-20"
            >
              <div className="relative w-full h-full overflow-hidden flex items-end justify-center">
                <img 
                  src="/photo.jpg" 
                  alt="Jonas Agra" 
                  className="w-full h-full object-cover object-center brightness-110 contrast-125"
                  style={{ 
                    maskImage: 'linear-gradient(to bottom, black 80%, transparent 100%)',
                    WebkitMaskImage: 'linear-gradient(to bottom, black 80%, transparent 100%)'
                  }}
                />
              </div>
            </motion.div>
          </div>

          {/* Water Transition Effect (Large Organic Wave) */}
          <div className="absolute bottom-[-5px] left-0 w-[101%] overflow-hidden leading-none z-10 text-zinc-950 pointer-events-none">
            <svg 
              className="relative block w-full h-[80px] md:h-[200px]"
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 1440 320" 
              preserveAspectRatio="none"
            >
              <path 
                fill="currentColor"
                d="M0,160L48,176C96,192,192,224,288,218.7C384,213,480,171,576,165.3C672,160,768,192,864,208C960,224,1056,224,1152,208C1248,192,1344,160,1392,144L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
              ></path>
            </svg>
          </div>
        </div>
      </section>


      {/* 2. INTRO SECTION */}
      <section className="relative py-24 md:py-48 px-4 max-w-5xl mx-auto flex flex-col gap-12 md:gap-24 overflow-hidden pt-32">
        
        {/* Small Description */}
        <RevealText className="flex flex-col gap-6 max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-purple-500">About Me</p>
          <h3 className="text-2xl md:text-4xl font-semibold leading-relaxed">
            "Olá, sou <span className="text-white">Jonas Agra</span>, tenho 25 anos, sou um estudante de Engenharia de Software. Entusiasta por tecnologia e desenvolvimento web."
          </h3>
        </RevealText>

        {/* Medium Description */}
        <RevealText delay={0.2} className="flex flex-col gap-6 ml-auto max-w-2xl text-right">
          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-500">Service Specialty</p>
          <h4 className="text-xl md:text-3xl font-medium text-zinc-400 leading-relaxed italic">
            "Aqui, eu cuido do seu site, faço manutenção e criação de websites como landing pages e SaaS para gestão de pequenas e médias empresas usando React, Node.js, e um pouco de Python para otimização de dados."
          </h4>
        </RevealText>

        {/* English Phrase */}
        <RevealText delay={0.4} className="flex flex-col items-center gap-4 py-12 text-center">
          <div className="relative group perspective-1000">
            <h5 className="text-5xl md:text-8xl font-black tracking-tighter text-white opacity-40 group-hover:opacity-100 transition-all duration-700 ease-out group-hover:[transform:rotateX(10deg)_scale(1.05)] cursor-default">
              Managed hosting with me
            </h5>
            <div className="absolute -inset-10 bg-purple-600/20 blur-[100px] opacity-0 group-hover:opacity-100 transition-opacity duration-1000 -z-10 rounded-full" />
          </div>
          <p className="text-zinc-500 font-medium tracking-wide uppercase text-sm mt-4">
            Hospedagem e manutenção gerenciada por mim
          </p>
        </RevealText>
      </section>

      {/* 3. LOGO MARQUEE SECTION */}
      <section className="py-24 bg-zinc-950 border-y border-white/5 space-y-4">
        <LogoMarquee 
          items={["Wordpress", "Vercel", "Github Pages", "Cloudflare Pages", "Amazon AWS", "DigitalOcean"]} 
          speed={30}
          direction="left"
        />
        <LogoMarquee 
          items={["React", "Next.js", "Javascript", "Python", "Prisma", "TailwindCSS", "Node.js", "GSAP"]} 
          speed={35}
          direction="right"
        />
      </section>

      {/* 4. PRICING SECTION */}
      <section className="py-24 md:py-48 px-4 bg-vibrant relative overflow-hidden">
        {/* Geometric Decor */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 blur-[150px] -z-10 rounded-full" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-cyan-600/10 blur-[150px] -z-10 rounded-full" />

        <div className="max-w-7xl mx-auto">
          <RevealText className="text-center mb-16 md:mb-24">
            <h2 className="text-5xl md:text-7xl font-black mb-6">ESCOLHA SEU <span className="neon-text">PLANO</span></h2>
            <p className="text-zinc-400 max-w-xl mx-auto">Soluções escaláveis para cada etapa do seu negócio digital.</p>
          </RevealText>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <PricingCard 
              name="Starter"
              price="79,90"
              features={[
                "1 Página",
                "Landing Page Responsiva",
                "Hospedagem em Vercel / GitHub Pages / Cloudflare Pages",
                "Integração com WhatsApp",
                "Formulário de Contato",
                "SEO Básico",
                "Certificado SSL",
                "Suporte Básico"
              ]}
              delay={0.1}
            />
            <PricingCard 
              name="Core"
              price="199,90"
              highlight
              features={[
                "Até 3 Páginas",
                "Plataformas Modernas (WordPress/Bubble)",
                "Hospedagem Gerenciada",
                "Domínio Personalizado",
                "Integração Social Medias",
                "Formulários Avançados",
                "Otimização de Performance",
                "Suporte Intermediário"
              ]}
              delay={0.2}
            />
            <PricingCard 
              name="Premium"
              price="349,90"
              features={[
                "Estrutura Avançada",
                "Painel Administrativo Simples",
                "Configuração WordPress Completa",
                "Dashboard Básico",
                "Integração com Gestão",
                "Design e UX Estratégico",
                "Suporte Prioritário",
                "Manutenção Avançada"
              ]}
              delay={0.3}
            />
            <PricingCard 
              name="Business"
              price="499,90"
              features={[
                "Estrutura Empresarial Completa",
                "Hospedagem Premium Gerenciada",
                "Soluções Avançadas Bubble",
                "Integração com Recursos de IA",
                "Automação Inteligente",
                "E-Commerce Básico",
                "SEO Avançado",
                "Suporte e Manutenção Máxima"
              ]}
              delay={0.4}
            />
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-12 border-t border-white/10 text-center">
        <p className="text-zinc-500 font-medium text-sm tracking-widest uppercase">
          Designed by <span className="text-white">Jonas Agra</span> - 2026
        </p>
      </footer>
    </main>
  );
}

const PricingCard = ({ 
  name, 
  price, 
  features, 
  highlight = false,
  delay = 0 
}: { 
  name: string, 
  price: string, 
  features: string[], 
  highlight?: boolean,
  delay?: number
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50, rotateY: 30, scale: 0.9 }}
      whileInView={{ opacity: 1, y: 0, rotateY: 0, scale: 1 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.8, delay, ease: [0.25, 0.46, 0.45, 0.94] }}
      whileHover={{ y: -10, rotateX: 5, rotateY: -5, scale: 1.02 }}
      className={cn(
        "relative p-8 rounded-3xl flex flex-col group transition-all duration-300 transform-gpu",
        highlight ? "glass ring-2 ring-purple-500 shadow-[0_0_40px_-10px_rgba(168,85,247,0.4)]" : "bg-zinc-900/40 border border-white/5 hover:border-white/20 hover:shadow-2xl hover:bg-zinc-900/60"
      )}
      style={{ transformStyle: "preserve-3d" }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-cyan-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl -z-10 pointer-events-none" />
      {highlight && (
        <span className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-purple-500 text-white text-[10px] font-bold uppercase tracking-widest rounded-full shadow-[0_0_20px_rgba(168,85,247,0.6)]">
          Mais popular
        </span>
      )}

      <motion.div className="mb-8" style={{ transform: "translateZ(30px)" }}>
        <h3 className="text-xl font-bold text-zinc-400 mb-2">{name}</h3>
        <div className="flex items-baseline gap-1">
          <span className="text-sm font-bold text-zinc-500">R$</span>
          <span className="text-4xl md:text-5xl font-black text-white drop-shadow-md">{price}</span>
          <span className="text-sm font-medium text-zinc-500">/mês</span>
        </div>
      </motion.div>

      <ul className="flex-grow space-y-4 mb-10 relative z-10" style={{ transform: "translateZ(20px)" }}>
        {features.map((feature, i) => (
          <li key={i} className="flex items-start gap-3 text-sm text-zinc-400 group-hover:text-zinc-200 transition-colors">
            <Check className="w-4 h-4 mt-0.5 text-purple-500 shrink-0 drop-shadow-[0_0_8px_rgba(168,85,247,1)]" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>

      <motion.a 
        href={getWhatsAppLink(name)}
        target="_blank"
        rel="noopener noreferrer"
        style={{ transform: "translateZ(40px)" }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className={cn(
          "w-full py-4 rounded-xl flex items-center justify-center gap-2 font-bold uppercase tracking-widest text-sm transition-all duration-300 relative overflow-hidden",
          highlight 
            ? "bg-purple-600 text-white shadow-[0_10px_20px_-10px_rgba(168,85,247,0.8)] hover:bg-purple-500" 
            : "bg-white text-black shadow-lg hover:bg-zinc-200"
        )}
      >
        <MessageCircle className="w-4 h-4 relative z-10" />
        <span className="relative z-10">Contratar</span>
        <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
      </motion.a>
    </motion.div>
  );
};

